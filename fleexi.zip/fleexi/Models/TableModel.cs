﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace Flexi2.Models
{
    // Needs change notifications because the admin can drag tables around on the floor plan.
    public sealed class TableModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

        private bool SetField<T>(ref T field, T value, [CallerMemberName] string? name = null)
        {
            if (Equals(field, value)) return false;
            field = value;
            OnPropertyChanged(name);
            return true;
        }

        public int Id { get; set; }
        public int ZoneId { get; set; }
        private string _name = "";
        public string Name
        {
            get => _name;
            set => SetField(ref _name, value);
        }
        private TableStatus _status;
        public TableStatus Status
        {
            get => _status;
            set
            {
                if (SetField(ref _status, value))
                {
                    OnPropertyChanged(nameof(StatusDisplay));
                    OnPropertyChanged(nameof(IsOccupied));
                    OnPropertyChanged(nameof(OccupiedByDisplay));
                    OnPropertyChanged(nameof(OpenedAtDisplay));
                    OnPropertyChanged(nameof(TableNumberBrush));
                    OnPropertyChanged(nameof(TableBorderBrush));
                    OnPropertyChanged(nameof(TableOwnerShort));
                    OnPropertyChanged(nameof(FreeStatusDisplay));
                }
            }
        }

        public bool IsOccupied => Status == TableStatus.Occupied;

        public string StatusDisplay => Status == TableStatus.Occupied ? "Заета" : "Свободна";

        // Layout (admin can position tables on the floor plan)
        private double _posX = 20;
        public double PosX
        {
            get => _posX;
            set => SetField(ref _posX, value);
        }

        private double _posY = 20;
        public double PosY
        {
            get => _posY;
            set => SetField(ref _posY, value);
        }

        private double _width = 170;
        public double Width
        {
            get => _width;
            set => SetField(ref _width, value);
        }

        private double _height = 120;
        public double Height
        {
            get => _height;
            set => SetField(ref _height, value);
        }


        // POS-only calculated layout. Admin keeps PosX/PosY/Width/Height,
        // POS uses these Display* values so the same layout fills the full screen.
        private double _displayPosX;
        public double DisplayPosX
        {
            get => _displayPosX;
            set => SetField(ref _displayPosX, value);
        }

        private double _displayPosY;
        public double DisplayPosY
        {
            get => _displayPosY;
            set => SetField(ref _displayPosY, value);
        }

        private double _displayWidth;
        public double DisplayWidth
        {
            get => _displayWidth <= 0 ? Width : _displayWidth;
            set => SetField(ref _displayWidth, value);
        }

        private double _displayHeight;
        public double DisplayHeight
        {
            get => _displayHeight <= 0 ? Height : _displayHeight;
            set => SetField(ref _displayHeight, value);
        }

        // 0 = Квадрат, 1 = Правоъгълник, 2 = Кръг
        private int _shapeType = 0;
        public int ShapeType
        {
            get => _shapeType;
            set
            {
                if (SetField(ref _shapeType, value))
                    OnPropertyChanged(nameof(ShapeDisplay));
            }
        }

        public string ShapeDisplay => ShapeType switch
        {
            2 => "Кръг",
            1 => "Правоъгълник",
            _ => "Квадрат"
        };

        public int? OwnerUserId { get; set; }
        public string OwnerUserName { get; set; } = string.Empty;
        public DateTime? OpenedAtUtc { get; set; }
        public decimal CurrentTotal { get; set; }
        public string OrderPreviewText { get; set; } = string.Empty;
        public List<TableOrderLineModel> OrderLines { get; set; } = new();
        public bool HasOrderLines => OrderLines.Count > 0;

        public string TableNumberBrush => IsOccupied ? "#FF1744" : "#FFFFFF";
        public string TableBorderBrush => IsOccupied ? "#FF1744" : "#B400FF";
        public string TableOwnerShort =>
            Status == TableStatus.Occupied && !string.IsNullOrWhiteSpace(OwnerUserName)
                ? OwnerUserName
                : string.Empty;
        public string FreeStatusDisplay => Status == TableStatus.Occupied ? string.Empty : "Свободна";

        public string OccupiedByDisplay =>
            Status == TableStatus.Occupied && !string.IsNullOrWhiteSpace(OwnerUserName)
                ? $"Заета от: {OwnerUserName}"
                : string.Empty;

        // Часът вече не се показва по желание на клиента.
        public string OpenedAtDisplay => string.Empty;
    }

    public sealed class TableOrderLineModel
    {
        public string ProductName { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal TotalPrice { get; set; }
    }
}
