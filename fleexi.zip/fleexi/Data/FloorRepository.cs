﻿using Flexi2.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Flexi2.Data
{
    public sealed class FloorRepository
    {
        public FloorRepository()
        {
        }

        public int AddZone(string name)
        {
            var row = new SupabaseZoneRow
            {
                Name = name
            };

            var result = App.SupabaseClient
                .From<SupabaseZoneRow>()
                .Insert(row)
                .GetAwaiter()
                .GetResult();

            return result.Models.First().Id;
        }

        public void DeleteZone(int zoneId)
        {
            var tables = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("zone_id", Supabase.Postgrest.Constants.Operator.Equals, zoneId)
                .Get()
                .GetAwaiter()
                .GetResult();

            if (tables.Models.Count > 0)
                throw new InvalidOperationException("Зоната има маси. Първо изтрий масите.");

            App.SupabaseClient
                .From<SupabaseZoneRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, zoneId)
                .Delete()
                .GetAwaiter()
                .GetResult();
        }

        public int AddTable(int zoneId, string name, int shapeType = 0)
        {
            var existingTables = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("zone_id", Supabase.Postgrest.Constants.Operator.Equals, zoneId)
                .Get()
                .GetAwaiter()
                .GetResult();

            var idx = existingTables.Models.Count;
            var x = 20 + (idx % 4) * 190;
            var y = 20 + (idx / 4) * 140;

            // Нормални начални размери. Преди при една маса admin layout-ът я уголемяваше визуално.
            var defaultWidth = shapeType == 1 ? 210 : 130;
            var defaultHeight = shapeType == 1 ? 110 : 130;

            var row = new SupabaseTableRow
            {
                ZoneId = zoneId,
                Name = name,
                PosX = x,
                PosY = y,
                Width = defaultWidth,
                Height = defaultHeight,
                ShapeType = shapeType,
                Status = 0,
                OwnerUserId = null,
                OpenedAtUtc = null,
                CurrentTotal = 0m
            };

            var result = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Insert(row)
                .GetAwaiter()
                .GetResult();

            return result.Models.First().Id;
        }

        public void UpdateTableLayout(int tableId, double x, double y, double? width = null, double? height = null)
        {
            var table = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, tableId)
                .Single()
                .GetAwaiter()
                .GetResult();

            table.PosX = x;
            table.PosY = y;

            if (width.HasValue)
                table.Width = width.Value;

            if (height.HasValue)
                table.Height = height.Value;

            App.SupabaseClient
                .From<SupabaseTableRow>()
                .Update(table)
                .GetAwaiter()
                .GetResult();
        }

        public void UpdateTableShape(int tableId, int shapeType, double width, double height)
        {
            var table = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, tableId)
                .Single()
                .GetAwaiter()
                .GetResult();

            table.ShapeType = shapeType;
            table.Width = width;
            table.Height = height;

            App.SupabaseClient
                .From<SupabaseTableRow>()
                .Update(table)
                .GetAwaiter()
                .GetResult();
        }


        public void UpdateTableNameAndShape(int tableId, string name, int shapeType, double width, double height)
        {
            var table = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, tableId)
                .Single()
                .GetAwaiter()
                .GetResult();

            table.Name = name;
            table.ShapeType = shapeType;
            table.Width = width;
            table.Height = height;

            App.SupabaseClient
                .From<SupabaseTableRow>()
                .Update(table)
                .GetAwaiter()
                .GetResult();
        }

        public void DeleteTable(int tableId)
        {
            App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, tableId)
                .Delete()
                .GetAwaiter()
                .GetResult();
        }

        public List<ZoneModel> GetZones()
        {
            var zoneRows = App.SupabaseClient
                .From<SupabaseZoneRow>()
                .Get()
                .GetAwaiter()
                .GetResult()
                .Models
                .OrderBy(z => z.Id)
                .ToList();

            var tableRows = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Get()
                .GetAwaiter()
                .GetResult()
                .Models
                .OrderBy(t => t.ZoneId)
                .ThenBy(t => t.Id)
                .ToList();

            var usersById = App.SupabaseClient
                .From<User>()
                .Get()
                .GetAwaiter()
                .GetResult()
                .Models
                .ToDictionary(u => u.Id, u => u.Name);

            // Чете текущите отворени поръчки и артикулите им за Админ -> Маси и зони.
            // Всичко е в try/catch, за да не изчезва целият layout ако някое поле в Supabase е NULL.
            var orderPreviewByTableId = new Dictionary<int, string>();
            var orderLinesByTableId = new Dictionary<int, List<TableOrderLineModel>>();
            var calculatedTotalByTableId = new Dictionary<int, decimal>();
            try
            {
                var openOrders = App.SupabaseClient
                    .From<SupabaseOrderRow>()
                    .Filter("status", Supabase.Postgrest.Constants.Operator.Equals, "open")
                    .Get()
                    .GetAwaiter()
                    .GetResult()
                    .Models
                    .GroupBy(o => o.TableId)
                    .ToDictionary(g => g.Key, g => g.OrderByDescending(o => o.Id).First());

                if (openOrders.Count > 0)
                {
                    var openOrderIds = openOrders.Values.Select(o => o.Id).ToHashSet();

                    var allItems = App.SupabaseClient
                        .From<SupabaseOrderItemRow>()
                        .Get()
                        .GetAwaiter()
                        .GetResult()
                        .Models
                        .Where(i => openOrderIds.Contains(i.OrderId) && i.Quantity != 0)
                        .ToList();

                    foreach (var pair in openOrders)
                    {
                        var tableId = pair.Key;
                        var orderId = pair.Value.Id;
                        var itemsForOrder = allItems
                            .Where(i => i.OrderId == orderId)
                            .GroupBy(i => new { i.ProductId, i.ProductName })
                            .Select(g => new TableOrderLineModel
                            {
                                ProductName = string.IsNullOrWhiteSpace(g.Key.ProductName) ? "Артикул" : g.Key.ProductName,
                                Quantity = g.Sum(x => x.Quantity),
                                UnitPrice = g.FirstOrDefault()?.Price ?? 0m,
                                TotalPrice = g.Sum(x => (x.Price ?? 0m) * x.Quantity)
                            })
                            .Where(x => x.Quantity != 0)
                            .ToList();

                        orderLinesByTableId[tableId] = itemsForOrder;
                        calculatedTotalByTableId[tableId] = itemsForOrder.Sum(x => x.TotalPrice);

                        if (itemsForOrder.Count > 0)
                        {
                            var firstItems = itemsForOrder.Take(3).Select(x => $"{x.ProductName} x{x.Quantity}");
                            var more = itemsForOrder.Count > 3 ? $"\n+ още {itemsForOrder.Count - 3}" : string.Empty;
                            orderPreviewByTableId[tableId] = string.Join("\n", firstItems) + more;
                        }
                    }
                }
            }
            catch
            {
                orderPreviewByTableId.Clear();
                orderLinesByTableId.Clear();
                calculatedTotalByTableId.Clear();
            }

            var zones = zoneRows.Select(z => new ZoneModel
            {
                Id = z.Id,
                Name = z.Name,
                Tables = new List<TableModel>()
            }).ToList();

            foreach (var zone in zones)
            {
                var tablesForZone = tableRows
                    .Where(t => t.ZoneId == zone.Id)
                    .Select(t => new TableModel
                    {
                        Id = t.Id,
                        ZoneId = t.ZoneId,
                        Name = t.Name,
                        PosX = t.PosX,
                        PosY = t.PosY,
                        Width = t.Width,
                        Height = t.Height,
                        ShapeType = t.ShapeType,
                        Status = (TableStatus)t.Status,
                        OwnerUserId = t.OwnerUserId,
                        OwnerUserName = t.OwnerUserId.HasValue && usersById.TryGetValue(t.OwnerUserId.Value, out var ownerName)
                            ? ownerName
                            : string.Empty,
                        OpenedAtUtc = TryParseDate(t.OpenedAtUtc),
                        CurrentTotal = calculatedTotalByTableId.TryGetValue(t.Id, out var calcTotal) && calcTotal > 0m
                            ? calcTotal
                            : (t.CurrentTotal ?? 0m),
                        OrderPreviewText = orderPreviewByTableId.TryGetValue(t.Id, out var preview)
                            ? preview
                            : string.Empty,
                        OrderLines = orderLinesByTableId.TryGetValue(t.Id, out var lines)
                            ? lines
                            : new List<TableOrderLineModel>()
                    })
                    .ToList();

                zone.Tables = tablesForZone;
            }

            return zones;
        }

        private static DateTime? TryParseDate(string? value)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            return DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var dt)
                ? dt
                : null;
        }

        public void SetTableOccupied(int tableId, int ownerUserId)
        {
            var table = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, tableId)
                .Single()
                .GetAwaiter()
                .GetResult();

            table.Status = 1;
            table.OwnerUserId = ownerUserId;
            table.OpenedAtUtc = DateTime.UtcNow.ToString("O");

            App.SupabaseClient
                .From<SupabaseTableRow>()
                .Update(table)
                .GetAwaiter()
                .GetResult();
        }

        public void SetTableFree(int tableId)
        {
            var table = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, tableId)
                .Single()
                .GetAwaiter()
                .GetResult();

            table.Status = 0;
            table.OwnerUserId = null;
            table.OpenedAtUtc = null;
            table.CurrentTotal = 0m;

            App.SupabaseClient
                .From<SupabaseTableRow>()
                .Update(table)
                .GetAwaiter()
                .GetResult();
        }

        public void UpdateTableTotal(int tableId, decimal total)
        {
            var table = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, tableId)
                .Single()
                .GetAwaiter()
                .GetResult();

            table.CurrentTotal = total;

            App.SupabaseClient
                .From<SupabaseTableRow>()
                .Update(table)
                .GetAwaiter()
                .GetResult();
        }
    }
}