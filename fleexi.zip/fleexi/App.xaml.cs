using System.Collections.Generic;
using System.Windows;
using Flexi2.Core.Security;
using Flexi2.Models;
using Supabase;

namespace Flexi2
{
    public partial class App : Application
    {
        public static Supabase.Client SupabaseClient;

        protected override async void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            var url = "https://piyhpiiqmphtrrwqjgbn.supabase.co";
            var key = "sb_publishable_OapgbUIscS0DkYU00FS3gg_EHXJ6KgF";
            
            var options = new SupabaseOptions
            {
                AutoConnectRealtime = true
            };

            SupabaseClient = new Supabase.Client(url, key, options);
            await SupabaseClient.InitializeAsync();

            await SeedSupabaseUsersIfEmpty();

            var window = new MainWindow();
            MainWindow = window;
            ShutdownMode = ShutdownMode.OnMainWindowClose;
            window.Show();
        }

        private async Task SeedSupabaseUsersIfEmpty()
        {
            var existing = await SupabaseClient
                .From<UserRow>()
                .Get();

            if (existing.Models.Count > 0)
                return;

            var posSalt = PinHasher.NewSaltHex();
            var adminSalt = PinHasher.NewSaltHex();

            var users = new List<UserRow>
            {
                new UserRow
                {
                    Name = "POS",
                    PinSalt = posSalt,
                    PinHash = PinHasher.Hash("1111", posSalt),
                    RoleValue = (int)UserRole.Pos,
                    IsActive = true
                },
                new UserRow
                {
                    Name = "ADMIN",
                    PinSalt = adminSalt,
                    PinHash = PinHasher.Hash("9999", adminSalt),
                    RoleValue = (int)UserRole.Admin,
                    IsActive = true
                }
            };

            await SupabaseClient
                .From<UserRow>()
                .Insert(users);
        }
    }
}