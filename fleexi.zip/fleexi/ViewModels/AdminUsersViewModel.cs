﻿using Flexi2.Core.MVVM;
using Flexi2.Models;
using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;

namespace Flexi2.ViewModels
{
    public sealed class AdminUsersViewModel : ObservableObject
    {
        private readonly MainViewModel _main;
        private readonly object _usersLock = new();

        public ObservableCollection<User> Users { get; } = new();

        private User? _selected;
        public User? Selected
        {
            get => _selected;
            set { _selected = value; OnPropertyChanged(); }
        }

        private string _newName = "";
        public string NewName
        {
            get => _newName;
            set { _newName = value; OnPropertyChanged(); }
        }

        private string _newPin = "";
        public string NewPin
        {
            get => _newPin;
            set { _newPin = value; OnPropertyChanged(); }
        }

        private int _newRoleInt = 0; // 0 POS, 1 ADMIN
        public int NewRoleInt
        {
            get => _newRoleInt;
            set { _newRoleInt = value; OnPropertyChanged(); }
        }

        private string _error = string.Empty;
        public string Error
        {
            get => _error;
            set => SetProperty(ref _error, value);
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                if (SetProperty(ref _isBusy, value))
                    System.Windows.Input.CommandManager.InvalidateRequerySuggested();
            }
        }

        public RelayCommand CreateCommand { get; }
        public RelayCommand SaveSelectedCommand { get; }
        public RelayCommand ChangePinCommand { get; }
        public RelayCommand DeleteCommand { get; }
        public RelayCommand LogoutCommand { get; }
        public RelayCommand BackToActivitiesCommand { get; }
        public RelayCommand BackCommand { get; }

        public AdminUsersViewModel(MainViewModel main)
        {
            _main = main;

            BindingOperations.EnableCollectionSynchronization(Users, _usersLock);

            CreateCommand = new RelayCommand(async _ => await CreateAsync());
            SaveSelectedCommand = new RelayCommand(async _ => await SaveSelectedAsync());
            ChangePinCommand = new RelayCommand(async _ => await ChangePinAsync());
            DeleteCommand = new RelayCommand(async _ => await DeleteAsync());

            LogoutCommand = new RelayCommand(_ =>
            {
                if (IsBusy) return;
                _main.Session.Logout();
                _main.Nav.NavigateTo(new LoginViewModel(_main));
            });

            BackToActivitiesCommand = new RelayCommand(_ =>
            {
                if (IsBusy) return;
                _main.Session.Logout();
                _main.Nav.NavigateTo(new LoginViewModel(_main));
            });

            BackCommand = new RelayCommand(_ =>
            {
                if (IsBusy) return;
                _main.Nav.NavigateTo(new AdminViewModel(_main));
            });

            _ = LoadAsync();
        }

        private async Task LoadAsync()
        {
            try
            {
                IsBusy = true;
                Error = string.Empty;

                var users = await _main.UsersRepo.GetAllAsync();

                await Application.Current.Dispatcher.InvokeAsync(() =>
                {
                    Users.Clear();
                    foreach (var u in users)
                        Users.Add(u);
                });
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
            }
        }

        private async Task CreateAsync()
        {
            try
            {
                IsBusy = true;
                Error = string.Empty;

                var name = (NewName ?? "").Trim();
                var pin = (NewPin ?? "").Trim();

                if (name.Length == 0 || pin.Length == 0)
                {
                    Error = "Име и PIN са задължителни";
                    return;
                }

                var role = NewRoleInt == 1 ? UserRole.Admin : UserRole.Pos;

                await Task.Run(() =>
                {
                    _main.UsersRepo.Create(name, role, pin);
                });

                NewName = "";
                NewPin = "";
                NewRoleInt = 0;

                OnPropertyChanged(nameof(NewName));
                OnPropertyChanged(nameof(NewPin));
                OnPropertyChanged(nameof(NewRoleInt));

                await LoadAsync();
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
            }
        }

        private async Task SaveSelectedAsync()
        {
            try
            {
                IsBusy = true;
                Error = string.Empty;

                if (Selected == null)
                {
                    Error = "Избери потребител";
                    return;
                }

                var id = Selected.Id;
                var name = Selected.Name;
                var role = Selected.Role;
                var isActive = Selected.IsActive;

                await Task.Run(() =>
                {
                    _main.UsersRepo.UpdateNameRole(id, name, role, isActive);
                });

                await LoadAsync();
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
            }
        }

        private async Task ChangePinAsync()
        {
            try
            {
                IsBusy = true;
                Error = string.Empty;

                if (Selected == null)
                {
                    Error = "Избери потребител";
                    return;
                }

                var pin = (NewPin ?? "").Trim();
                if (pin.Length == 0)
                {
                    Error = "Въведи нов PIN в полето PIN";
                    return;
                }

                var userId = Selected.Id;

                await Task.Run(() =>
                {
                    _main.UsersRepo.ChangePin(userId, pin);
                });

                NewPin = "";
                OnPropertyChanged(nameof(NewPin));

                await LoadAsync();
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
            }
        }

        private async Task DeleteAsync()
        {
            try
            {
                IsBusy = true;
                Error = string.Empty;

                if (Selected == null)
                {
                    Error = "Избери потребител";
                    return;
                }

                var userId = Selected.Id;

                await Task.Run(() =>
                {
                    _main.UsersRepo.Delete(userId);
                });

                Selected = null;
                await LoadAsync();
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
            }
        }
    

        private static bool IsBulgarian(string text)
        {
            if (string.IsNullOrWhiteSpace(text))
                return false;

            return text.Any(c => (c >= 'А' && c <= 'я') || c == 'Ё' || c == 'ё');
        }

    } 
}
