﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace Flexi2.Converters
{
    public sealed class TablePercentMinSizeConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double actual = ToDouble(value, 0);
            var (percent, min, max) = Parse(parameter, 0.10, 155, 10000);
            if (actual <= 0) return min;
            return Math.Max(min, Math.Min(max, actual * percent));
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotSupportedException();

        private static (double percent, double min, double max) Parse(object parameter, double p, double min, double max)
        {
            var text = parameter?.ToString();
            if (string.IsNullOrWhiteSpace(text)) return (p, min, max);

            var parts = text.Split('|');
            if (parts.Length > 0) double.TryParse(parts[0], NumberStyles.Any, CultureInfo.InvariantCulture, out p);
            if (parts.Length > 1) double.TryParse(parts[1], NumberStyles.Any, CultureInfo.InvariantCulture, out min);
            if (parts.Length > 2) double.TryParse(parts[2], NumberStyles.Any, CultureInfo.InvariantCulture, out max);
            return (p, min, max);
        }

        private static double ToDouble(object value, double fallback)
        {
            try
            {
                if (value == null) return fallback;
                return System.Convert.ToDouble(value, CultureInfo.InvariantCulture);
            }
            catch { return fallback; }
        }
    }

    public sealed class TableAdaptiveSizeConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double size = ToDouble(value, 155);
            var (factor, min, max) = Parse(parameter, 0.12, 12, 32);
            return Math.Max(min, Math.Min(max, size * factor));
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotSupportedException();

        private static (double factor, double min, double max) Parse(object parameter, double factor, double min, double max)
        {
            var text = parameter?.ToString();
            if (string.IsNullOrWhiteSpace(text)) return (factor, min, max);

            var parts = text.Split('|');
            if (parts.Length > 0) double.TryParse(parts[0], NumberStyles.Any, CultureInfo.InvariantCulture, out factor);
            if (parts.Length > 1) double.TryParse(parts[1], NumberStyles.Any, CultureInfo.InvariantCulture, out min);
            if (parts.Length > 2) double.TryParse(parts[2], NumberStyles.Any, CultureInfo.InvariantCulture, out max);
            return (factor, min, max);
        }

        private static double ToDouble(object value, double fallback)
        {
            try
            {
                if (value == null) return fallback;
                return System.Convert.ToDouble(value, CultureInfo.InvariantCulture);
            }
            catch { return fallback; }
        }
    }

    public sealed class TableAdaptiveThicknessConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double size = ToDouble(value, 155);
            var (factor, min, max) = Parse(parameter, 0.20, 14, 80);
            double bottom = Math.Max(min, Math.Min(max, size * factor));
            return new Thickness(0, 0, 0, bottom);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            => throw new NotSupportedException();

        private static (double factor, double min, double max) Parse(object parameter, double factor, double min, double max)
        {
            var text = parameter?.ToString();
            if (string.IsNullOrWhiteSpace(text)) return (factor, min, max);

            var parts = text.Split('|');
            if (parts.Length > 0) double.TryParse(parts[0], NumberStyles.Any, CultureInfo.InvariantCulture, out factor);
            if (parts.Length > 1) double.TryParse(parts[1], NumberStyles.Any, CultureInfo.InvariantCulture, out min);
            if (parts.Length > 2) double.TryParse(parts[2], NumberStyles.Any, CultureInfo.InvariantCulture, out max);
            return (factor, min, max);
        }

        private static double ToDouble(object value, double fallback)
        {
            try
            {
                if (value == null) return fallback;
                return System.Convert.ToDouble(value, CultureInfo.InvariantCulture);
            }
            catch { return fallback; }
        }
    }

    public sealed class TableNameFontMultiConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            double width = values.Length > 0 ? ToDouble(values[0], 120) : 120;
            double height = values.Length > 1 ? ToDouble(values[1], 120) : 120;
            var (factor, min, max) = Parse(parameter, 0.18, 11, 34);
            double size = Math.Min(width, height);
            return Math.Max(min, Math.Min(max, size * factor));
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
            => throw new NotSupportedException();

        private static (double factor, double min, double max) Parse(object parameter, double factor, double min, double max)
        {
            var text = parameter?.ToString();
            if (string.IsNullOrWhiteSpace(text)) return (factor, min, max);

            var parts = text.Split('|');
            if (parts.Length > 0) double.TryParse(parts[0], NumberStyles.Any, CultureInfo.InvariantCulture, out factor);
            if (parts.Length > 1) double.TryParse(parts[1], NumberStyles.Any, CultureInfo.InvariantCulture, out min);
            if (parts.Length > 2) double.TryParse(parts[2], NumberStyles.Any, CultureInfo.InvariantCulture, out max);
            return (factor, min, max);
        }

        private static double ToDouble(object value, double fallback)
        {
            try
            {
                if (value == null || value == DependencyProperty.UnsetValue) return fallback;
                return System.Convert.ToDouble(value, CultureInfo.InvariantCulture);
            }
            catch { return fallback; }
        }
    }

    public sealed class TableNameRotationConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            double width = values.Length > 0 ? ToDouble(values[0], 120) : 120;
            double height = values.Length > 1 ? ToDouble(values[1], 120) : 120;

            // If the table is much taller than it is wide, rotate the name so it stays readable.
            return height > width * 1.18 ? -90.0 : 0.0;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
            => throw new NotSupportedException();

        private static double ToDouble(object value, double fallback)
        {
            try
            {
                if (value == null || value == DependencyProperty.UnsetValue) return fallback;
                return System.Convert.ToDouble(value, CultureInfo.InvariantCulture);
            }
            catch { return fallback; }
        }
    }

}
