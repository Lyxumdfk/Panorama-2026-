﻿using System;
using System.Collections.ObjectModel;
using Flexi2.Core.MVVM;
using Flexi2.Models;
using System.Windows;
using System.Windows.Controls;
using System.Globalization;

namespace Flexi2.ViewModels
{
    public sealed class AdminMenuViewModel : ObservableObject
    {
        private readonly MainViewModel _main;

        public ObservableCollection<Category> Categories { get; } = new();
        public ObservableCollection<Product> Products { get; } = new();

        private Category? _selectedCategory;
        public Category? SelectedCategory
        {
            get => _selectedCategory;
            set
            {
                _selectedCategory = value;
                OnPropertyChanged();
                LoadProducts();
            }
        }

        private Product? _selectedProduct;
        public Product? SelectedProduct
        {
            get => _selectedProduct;
            set { _selectedProduct = value; OnPropertyChanged(); }
        }

        private string _newCategoryName = "";
        public string NewCategoryName
        {
            get => _newCategoryName;
            set => SetProperty(ref _newCategoryName, value);
        }

        private string _newProductName = "";
        public string NewProductName
        {
            get => _newProductName;
            set => SetProperty(ref _newProductName, value);
        }

        private string _newProductPrice = "";
        public string NewProductPrice
        {
            get => _newProductPrice;
            set => SetProperty(ref _newProductPrice, value);
        }

        private int? _editingCategoryId;
        public int? EditingCategoryId
        {
            get => _editingCategoryId;
            set
            {
                _editingCategoryId = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(CategoryActionText));
            }
        }

        private int? _editingProductId;
        public int? EditingProductId
        {
            get => _editingProductId;
            set
            {
                _editingProductId = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(ProductActionText));
            }
        }

        private bool _productEditSelectionMode;
        public bool ProductEditSelectionMode
        {
            get => _productEditSelectionMode;
            set
            {
                _productEditSelectionMode = value;
                OnPropertyChanged();
            }
        }

        public string CategoryActionText => EditingCategoryId == null ? "ДОБАВИ" : "ЗАПАЗИ";
        public string ProductActionText => EditingProductId == null ? "ДОБАВИ" : "ЗАПАЗИ";

        private string _error = "";
        public string Error
        {
            get => _error;
            set { _error = value; OnPropertyChanged(); }
        }

        public RelayCommand BackCommand { get; }
        public RelayCommand BackToActivitiesCommand { get; }
        public RelayCommand AddCategoryCommand { get; }
        public RelayCommand DeleteCategoryCommand { get; }
        public RelayCommand ToggleCategoryActiveCommand { get; }
        public RelayCommand EditCategoryCommand { get; }
        public RelayCommand AddProductCommand { get; }
        public RelayCommand DeleteProductCommand { get; }
        public RelayCommand ToggleProductActiveCommand { get; }
        public RelayCommand EditProductCommand { get; }
        public RelayCommand StartProductEditSelectionCommand { get; }
        public RelayCommand SelectProductForEditCommand { get; }

        public AdminMenuViewModel(MainViewModel main)
        {
            _main = main;

            BackCommand = new RelayCommand(_ => _main.Nav.NavigateTo(new AdminViewModel(_main)));

            BackToActivitiesCommand = new RelayCommand(_ =>
            {
                _main.Session.Logout();
                _main.Nav.NavigateTo(new LoginViewModel(_main));
            });

            // ✅ REALTIME FIX (ВАЖНО)
            _main.Realtime.TableChanged += table =>
            {
                if (table == "categories" || table == "products")
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        var keepCategoryId = SelectedCategory?.Id;

                        LoadCategories();

                        if (keepCategoryId != null)
                        {
                            foreach (var c in Categories)
                            {
                                if (c.Id == keepCategoryId)
                                {
                                    SelectedCategory = c;
                                    break;
                                }
                            }
                        }

                        LoadProducts();
                    });
                }
            };

            AddCategoryCommand = new RelayCommand(_ =>
            {
                try
                {
                    Error = "";
                    var name = (NewCategoryName ?? "").Trim();
                    if (name.Length < 2) { Error = "Името е твърде кратко."; return; }

                    if (EditingCategoryId != null)
                    {
                        var keepCategoryId = EditingCategoryId.Value;
                        _main.MenuRepo.UpdateCategory(keepCategoryId, name);
                        EditingCategoryId = null;
                        NewCategoryName = "";
                        LoadCategories();
                        foreach (var c in Categories)
                        {
                            if (c.Id == keepCategoryId)
                            {
                                SelectedCategory = c;
                                break;
                            }
                        }
                    }
                    else
                    {
                        _main.MenuRepo.AddCategory(name);
                        NewCategoryName = "";
                        LoadCategories(true);
                    }
                }
                catch (Exception ex)
                {
                    Error = ex.Message;
                }
            });

            DeleteCategoryCommand = new RelayCommand(_ =>
            {
                if (SelectedCategory == null) return;
                _main.MenuRepo.DeleteCategory(SelectedCategory.Id);
                LoadCategories();
            });

            ToggleCategoryActiveCommand = new RelayCommand(p =>
            {
                var cat = p as Category ?? SelectedCategory;
                if (cat == null) return;
                _main.MenuRepo.SetCategoryActive(cat.Id, !cat.IsActive);
                var keepCategoryId = cat.Id;
                LoadCategories();
                foreach (var c in Categories)
                {
                    if (c.Id == keepCategoryId)
                    {
                        SelectedCategory = c;
                        break;
                    }
                }
            });

            EditCategoryCommand = new RelayCommand(p =>
            {
                var cat = p as Category ?? SelectedCategory;
                if (cat == null) return;

                SelectedCategory = cat;
                EditingCategoryId = cat.Id;
                NewCategoryName = cat.Name;
                Error = "Редакция на категория: промени името горе и натисни ЗАПАЗИ.";
            });

            AddProductCommand = new RelayCommand(_ =>
            {
                if (SelectedCategory == null) return;

                var name = (NewProductName ?? "").Trim();
                if (name.Length < 2)
                {
                    Error = "Името е твърде кратко.";
                    return;
                }

                if (!decimal.TryParse(NewProductPrice.Replace(',', '.'), System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out var price))
                {
                    Error = "Невалидна цена";
                    return;
                }

                if (price < 0)
                {
                    Error = "Цената не може да е отрицателна.";
                    return;
                }

                try
                {
                    Error = "";
                    if (EditingProductId != null)
                    {
                        _main.MenuRepo.UpdateProduct(EditingProductId.Value, name, price);
                        EditingProductId = null;
                        ProductEditSelectionMode = false;
                        NewProductName = "";
                        NewProductPrice = "";
                        LoadProducts();
                    }
                    else
                    {
                        _main.MenuRepo.AddProduct(SelectedCategory.Id, name, price, false);
                        ProductEditSelectionMode = false;
                        NewProductName = "";
                        NewProductPrice = "";
                        LoadProducts(true);
                    }
                }
                catch (Exception ex)
                {
                    Error = ex.Message;
                }
            });

            DeleteProductCommand = new RelayCommand(p =>
            {
                var pr = p as Product ?? SelectedProduct;
                if (pr == null) return;
                _main.MenuRepo.DeleteProduct(pr.Id);
                LoadProducts();
            });

            ToggleProductActiveCommand = new RelayCommand(p =>
            {
                var pr = p as Product ?? SelectedProduct;
                if (pr == null) return;
                _main.MenuRepo.SetProductActive(pr.Id, !pr.IsActive);
                LoadProducts();
            });

            StartProductEditSelectionCommand = new RelayCommand(_ =>
            {
                ProductEditSelectionMode = true;
                EditingProductId = null;
                NewProductName = "";
                NewProductPrice = "";
                Error = "Избери артикул от списъка, който искаш да редактираш.";
            });

            SelectProductForEditCommand = new RelayCommand(p =>
            {
                if (!ProductEditSelectionMode) return;
                var pr = p as Product;
                if (pr == null) return;

                SelectedProduct = pr;
                EditingProductId = pr.Id;
                ProductEditSelectionMode = false;
                NewProductName = pr.Name;
                NewProductPrice = pr.Price.ToString("0.00", CultureInfo.InvariantCulture);
                Error = "Редакция на артикул: промени името/цената горе и натисни ЗАПАЗИ.";
            });

            EditProductCommand = new RelayCommand(p =>
            {
                var pr = p as Product ?? SelectedProduct;
                if (pr == null) return;

                SelectedProduct = pr;
                EditingProductId = pr.Id;
                ProductEditSelectionMode = false;
                NewProductName = pr.Name;
                NewProductPrice = pr.Price.ToString("0.00", CultureInfo.InvariantCulture);
                Error = "Редакция на артикул: промени името/цената горе и натисни ЗАПАЗИ.";
            });

            LoadCategories();
        }

        private string? ShowTextEditDialog(string title, string label, string currentValue)
        {
            var textBox = new TextBox
            {
                Text = currentValue,
                FontSize = 18,
                MinWidth = 360,
                Margin = new Thickness(0, 8, 0, 0)
            };

            var dialog = CreateEditWindow(title);
            dialog.Content = new StackPanel
            {
                Margin = new Thickness(18),
                Children =
                {
                    new TextBlock
                    {
                        Text = label,
                        Foreground = System.Windows.Media.Brushes.White,
                        FontSize = 16,
                        FontWeight = FontWeights.Bold
                    },
                    textBox,
                    CreateDialogButtons(dialog)
                }
            };

            dialog.Loaded += (_, _) =>
            {
                textBox.Focus();
                textBox.SelectAll();
            };

            return dialog.ShowDialog() == true ? textBox.Text : null;
        }

        private (string Name, decimal Price)? ShowProductEditDialog(string currentName, decimal currentPrice)
        {
            var nameBox = new TextBox
            {
                Text = currentName,
                FontSize = 18,
                MinWidth = 420,
                Margin = new Thickness(0, 8, 0, 14)
            };

            var priceBox = new TextBox
            {
                Text = currentPrice.ToString("0.00", CultureInfo.InvariantCulture),
                FontSize = 18,
                MinWidth = 420,
                Margin = new Thickness(0, 8, 0, 0)
            };

            var dialog = CreateEditWindow("Редакция на артикул");
            dialog.Content = new StackPanel
            {
                Margin = new Thickness(18),
                Children =
                {
                    new TextBlock
                    {
                        Text = "Име на артикул",
                        Foreground = System.Windows.Media.Brushes.White,
                        FontSize = 16,
                        FontWeight = FontWeights.Bold
                    },
                    nameBox,
                    new TextBlock
                    {
                        Text = "Цена",
                        Foreground = System.Windows.Media.Brushes.White,
                        FontSize = 16,
                        FontWeight = FontWeights.Bold
                    },
                    priceBox,
                    CreateDialogButtons(dialog)
                }
            };

            dialog.Loaded += (_, _) =>
            {
                nameBox.Focus();
                nameBox.SelectAll();
            };

            if (dialog.ShowDialog() != true) return null;

            if (!decimal.TryParse(priceBox.Text.Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out var price))
            {
                Error = "Невалидна цена.";
                return null;
            }

            return (nameBox.Text, price);
        }

        private Window CreateEditWindow(string title)
        {
            return new Window
            {
                Title = title,
                Width = 520,
                SizeToContent = SizeToContent.Height,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = Application.Current.MainWindow,
                ResizeMode = ResizeMode.NoResize,
                Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(11, 17, 48)),
                Foreground = System.Windows.Media.Brushes.White,
                ShowInTaskbar = false
            };
        }

        private Grid CreateDialogButtons(Window dialog)
        {
            var grid = new Grid { Margin = new Thickness(0, 18, 0, 0) };
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(12) });
            grid.ColumnDefinitions.Add(new ColumnDefinition());

            var cancel = new Button
            {
                Content = "ОТКАЗ",
                Height = 46,
                FontWeight = FontWeights.Bold,
                BorderBrush = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(180, 0, 255))
            };
            cancel.Click += (_, _) => dialog.DialogResult = false;

            var save = new Button
            {
                Content = "ЗАПАЗИ",
                Height = 46,
                FontWeight = FontWeights.Bold
            };
            save.Click += (_, _) => dialog.DialogResult = true;

            Grid.SetColumn(cancel, 0);
            Grid.SetColumn(save, 2);
            grid.Children.Add(cancel);
            grid.Children.Add(save);
            return grid;
        }

        private void LoadCategories(bool selectLast = false)
        {
            Categories.Clear();
            foreach (var c in _main.MenuRepo.GetCategories(true))
                Categories.Add(c);

            if (Categories.Count == 0)
            {
                SelectedCategory = null;
                Products.Clear();
                return;
            }

            SelectedCategory = selectLast ? Categories[^1] : Categories[0];
        }

        private void LoadProducts(bool selectLast = false)
        {
            Products.Clear();
            if (SelectedCategory == null) return;

            foreach (var p in _main.MenuRepo.GetProducts(SelectedCategory.Id, true))
                Products.Add(p);

            if (selectLast && Products.Count > 0)
                SelectedProduct = Products[^1];
        }
    }
}