﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Linq;
using System.Windows;
using Flexi2.Core.MVVM;
using Flexi2.Models;

namespace Flexi2.ViewModels
{
    public sealed class FloorPlanViewModel : ObservableObject
    {
        private readonly MainViewModel _main;

        public string Title => "POS • МАСИ";

        public ObservableCollection<ZoneModel> Zones { get; } = new();
        public ObservableCollection<TableModel> Tables { get; } = new();

        private ZoneModel? _selectedZone;
        public ZoneModel? SelectedZone
        {
            get => _selectedZone;
            set
            {
                if (Set(ref _selectedZone, value))
                    ReloadTables();
            }
        }

        private string _error = string.Empty;
        public string Error
        {
            get => _error;
            set
            {
                if (Set(ref _error, value))
                    OnPropertyChanged(nameof(HasError));
            }
        }

        public bool HasError => !string.IsNullOrWhiteSpace(Error);

        private bool _isBusy;
        public bool IsBusy
        {
            get => _isBusy;
            set => Set(ref _isBusy, value);
        }

        public RelayCommand OpenMenuCommand { get; }
        public RelayCommand LogoutCommand { get; }
        public RelayCommand BackToLoginCommand { get; }
        public RelayCommand OpenTableCommand { get; }
        public RelayCommand RefreshCommand { get; }
        public RelayCommand CloseLockedMessageCommand { get; }

        public FloorPlanViewModel(MainViewModel main)
        {
            _main = main;

            OpenMenuCommand = new RelayCommand(_ =>
            {
                Error = "Избери маса и отвори сметка. Менюто се отваря вътре в сметката.";
            });

            OpenTableCommand = new RelayCommand(t =>
            {
                if (t is not TableModel table) return;

                Error = string.Empty;
                var user = _main.Session.CurrentUser;
                if (user == null)
                {
                    Error = "Няма активен потребител.";
                    return;
                }

                // Ако масата е заета от друг сервитьор, не позволяваме влизане,
                // добавяне на артикули или приключване на чужда сметка.
                if (table.Status == TableStatus.Occupied &&
                    table.OwnerUserId.HasValue &&
                    table.OwnerUserId.Value != user.Id)
                {
                    var ownerName = string.IsNullOrWhiteSpace(table.OwnerUserName) ? "друг сервитьор" : table.OwnerUserName;
                    Error = $"Маса {table.Name} е заета от: {ownerName}. Само сервитьорът, който я е отворил, може да влиза в сметката.";
                    return;
                }

                if (table.Status == TableStatus.Occupied && !table.OwnerUserId.HasValue)
                {
                    Error = $"Маса {table.Name} е заета. Няма записан собственик, затова сметката е заключена.";
                    return;
                }

                _main.Session.CurrentTableId = table.Id;
                var ticket = new TicketViewModel(_main, table.Id);
                _main.Nav.NavigateTo(new CategoryViewModel(_main, table.Id, ticket));
            });

            LogoutCommand = new RelayCommand(_ =>
            {
                _main.Session.Logout();
                _main.Nav.NavigateTo(new LoginViewModel(_main));
            });

            BackToLoginCommand = new RelayCommand(_ =>
            {
                _main.Session.Logout();
                _main.Nav.NavigateTo(new LoginViewModel(_main));
            });

            RefreshCommand = new RelayCommand(async _ => await LoadAsync());

            CloseLockedMessageCommand = new RelayCommand(_ =>
            {
                Error = string.Empty;
            });

            _ = LoadAsync();
        }

        private async Task LoadAsync()
        {
            try
            {
                IsBusy = true;
                Error = string.Empty;

                var zones = await Task.Run(() => _main.FloorRepo.GetZones());

                Application.Current.Dispatcher.Invoke(() =>
                {
                    Zones.Clear();
                    foreach (var z in zones)
                        Zones.Add(z);

                    SelectedZone = Zones.Count > 0 ? Zones[0] : null;
                    ReloadTables();
                });
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
            }
        }

        private void ReloadTables()
        {
            Tables.Clear();
            if (SelectedZone?.Tables == null) return;

            foreach (var t in SelectedZone.Tables)
                Tables.Add(t);
        }

        public void ApplyFullscreenTableLayout(double availableWidth, double availableHeight)
        {
            if (availableWidth <= 0 || availableHeight <= 0 || Tables.Count == 0)
                return;

            // POS трябва да използва цялото поле за маси от край до край.
            // Без вътрешен safe padding и без центриране, за да няма лява бариера.
            const double safePadding = 0.0;
            double usableWidth = Math.Max(1, availableWidth);
            double usableHeight = Math.Max(1, availableHeight);

            double minX = Tables.Min(t => t.PosX);
            double minY = Tables.Min(t => t.PosY);
            double maxRight = Tables.Max(t => t.PosX + t.Width);
            double maxBottom = Tables.Max(t => t.PosY + t.Height);

            double layoutWidth = Math.Max(1, maxRight - minX);
            double layoutHeight = Math.Max(1, maxBottom - minY);
            double scale = Math.Min(usableWidth / layoutWidth, usableHeight / layoutHeight);

            // Без центриране: най-лявата маса започва точно от X=0.
            double offsetX = 0.0;
            double offsetY = 0.0;

            foreach (var table in Tables)
            {
                table.DisplayPosX = offsetX + (table.PosX - minX) * scale;
                table.DisplayPosY = offsetY + (table.PosY - minY) * scale;
                table.DisplayWidth = Math.Max(48, table.Width * scale);
                table.DisplayHeight = Math.Max(48, table.Height * scale);
            }
        }

    }
}