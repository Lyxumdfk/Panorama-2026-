﻿using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;

namespace Flexi2.Models
{
    [Table("products")]
    public class ProductRow : BaseModel
    {
        [PrimaryKey("id", false)]
        public int Id { get; set; }

        [Column("name")]
        public string Name { get; set; } = string.Empty;

        [Column("price")]
        public decimal Price { get; set; }

        [Column("category")]
        public string Category { get; set; } = "Без категория";

        [Column("category_id")]
        public int CategoryId { get; set; }

        [Column("has_modifiers")]
        public bool HasModifiers { get; set; }

        [Column("is_active")]
        public bool IsActive { get; set; } = true;
    }
}