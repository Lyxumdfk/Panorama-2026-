﻿using System;
using System.IO;
using Flexi2.Core.MVVM;
using Flexi2.Navigation;
using Flexi2.Core.Session;
using Flexi2.Data;
using Flexi2.Services;

namespace Flexi2.ViewModels
{
    public sealed class MainViewModel : ObservableObject
    {
        private object? _currentViewModel;
        public object? CurrentViewModel
        {
            get => _currentViewModel;
            set
            {
                _currentViewModel = value;
                OnPropertyChanged();
            }
        }


        public SupabaseRealtimeService Realtime { get; }
        public SupabaseProductsService ProductsService { get; }
        public NavigationService Nav { get; }
        public UserSession Session { get; }

        public UserRepository UsersRepo { get; }
        public FloorRepository FloorRepo { get; }
        public MenuRepository MenuRepo { get; }
        public OrderRepository OrderRepo { get; }
        public ReportsRepository ReportsRepo { get; }
        public AuditRepository AuditRepo { get; }
        public SupabasePosService PosService { get; }

        public MainViewModel()
        {
            var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            var dbPath = Path.Combine(appData, "Flexi2", "flexi.db");
            var db = new FlexiDb(dbPath);
            ProductsService = new SupabaseProductsService();

            DbInit.EnsureCreated(db);

            UsersRepo = new UserRepository(db);

            // АКО FloorRepository е новият ти вариант без db:
            FloorRepo = new FloorRepository();

            // АКО ти даде грешка на горния ред, смени го с това:
            // FloorRepo = new FloorRepository(db);

            MenuRepo = new MenuRepository(db);
            OrderRepo = new OrderRepository(db);
            ReportsRepo = new ReportsRepository(db);
            AuditRepo = new AuditRepository(db);
            PosService = new SupabasePosService();

            Realtime = new SupabaseRealtimeService();
            _ = Realtime.StartAsync();

            Session = new UserSession();
            Nav = new NavigationService(vm => CurrentViewModel = vm);

            Nav.NavigateTo(new LoginViewModel(this));
        }

    }
}