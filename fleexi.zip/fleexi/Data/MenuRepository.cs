using Flexi2.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;

namespace Flexi2.Data
{
    public sealed class MenuRepository
    {
        private const string SupabaseUrl = "https://piyhpiiqmphtrrwqjgbn.supabase.co";
        private const string SupabaseAnonKey = "sb_publishable_OapgbUIscS0DkYU00FS3gg_EHXJ6KgF";

        private readonly HttpClient _http = new HttpClient();

        public MenuRepository(FlexiDb db)
        {
            _http.BaseAddress = new Uri($"{SupabaseUrl}/rest/v1/");
            _http.DefaultRequestHeaders.Add("apikey", SupabaseAnonKey);
            _http.DefaultRequestHeaders.Add("Authorization", $"Bearer {SupabaseAnonKey}");
        }

        public List<Category> GetCategories(bool includeInactive = false)
        {
            var url = includeInactive
                ? "categories?select=id,name,isactive&order=name.asc"
                : "categories?select=id,name,isactive&isactive=eq.true&order=name.asc";

            var json = _http.GetStringAsync(url).GetAwaiter().GetResult();
            var doc = JsonDocument.Parse(json);

            var list = new List<Category>();

            foreach (var row in doc.RootElement.EnumerateArray())
            {
                list.Add(new Category
                {
                    Id = row.GetProperty("id").GetInt32(),
                    Name = row.GetProperty("name").GetString() ?? "",
                    IsActive = row.GetProperty("isactive").GetBoolean()
                });
            }

            return list;
        }

        public List<Product> GetProducts(int categoryId, bool includeInactive = false)
        {
            var url = includeInactive
                ? $"products?select=id,category_id,name,price,isactive&category_id=eq.{categoryId}&order=name.asc"
                : $"products?select=id,category_id,name,price,isactive&category_id=eq.{categoryId}&isactive=eq.true&order=name.asc";

            var json = _http.GetStringAsync(url).GetAwaiter().GetResult();
            var doc = JsonDocument.Parse(json);

            var list = new List<Product>();

            foreach (var row in doc.RootElement.EnumerateArray())
            {
                list.Add(new Product
                {
                    Id = row.GetProperty("id").GetInt32(),
                    CategoryId = row.GetProperty("category_id").GetInt32(),
                    Name = row.GetProperty("name").GetString() ?? "",
                    Price = row.GetProperty("price").GetDecimal(),
                    IsActive = row.GetProperty("isactive").GetBoolean(),
                    HasModifiers = false
                });
            }

            return list;
        }

        public int AddCategory(string name)
        {
            var body = JsonSerializer.Serialize(new
            {
                name = name.Trim(),
                isactive = true
            });

            var request = new HttpRequestMessage(HttpMethod.Post, "categories?select=id");
            request.Content = new StringContent(body, Encoding.UTF8, "application/json");
            request.Headers.Add("Prefer", "return=representation");

            var response = _http.SendAsync(request).GetAwaiter().GetResult();
            response.EnsureSuccessStatusCode();

            var json = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
            var doc = JsonDocument.Parse(json);

            return doc.RootElement[0].GetProperty("id").GetInt32();
        }

        public void SetCategoryActive(int id, bool isActive)
        {
            Patch($"categories?id=eq.{id}", new { isactive = isActive });
            Patch($"products?category_id=eq.{id}", new { isactive = isActive });
        }

        public void UpdateCategory(int id, string name)
        {
            Patch($"categories?id=eq.{id}", new { name = name.Trim() });
        }

        public int AddProduct(int categoryId, string name, decimal price, bool hasModifiers)
        {
            var body = JsonSerializer.Serialize(new
            {
                category_id = categoryId,
                name = name.Trim(),
                price = price,
                isactive = true
            });

            var request = new HttpRequestMessage(HttpMethod.Post, "products?select=id");
            request.Content = new StringContent(body, Encoding.UTF8, "application/json");
            request.Headers.Add("Prefer", "return=representation");

            var response = _http.SendAsync(request).GetAwaiter().GetResult();
            response.EnsureSuccessStatusCode();

            var json = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
            var doc = JsonDocument.Parse(json);

            return doc.RootElement[0].GetProperty("id").GetInt32();
        }

        public void SetProductActive(int productId, bool isActive)
        {
            Patch($"products?id=eq.{productId}", new { isactive = isActive });
        }

        public void UpdateProduct(int productId, string name, decimal price)
        {
            Patch($"products?id=eq.{productId}", new
            {
                name = name.Trim(),
                price = price
            });
        }

        public void DeleteProduct(int productId)
        {
            var response = _http.DeleteAsync($"products?id=eq.{productId}").GetAwaiter().GetResult();
            response.EnsureSuccessStatusCode();
        }

        public void DeleteCategory(int categoryId)
        {
            _http.DeleteAsync($"products?category_id=eq.{categoryId}").GetAwaiter().GetResult().EnsureSuccessStatusCode();
            _http.DeleteAsync($"categories?id=eq.{categoryId}").GetAwaiter().GetResult().EnsureSuccessStatusCode();
        }

        private void Patch(string url, object data)
        {
            var body = JsonSerializer.Serialize(data);

            var request = new HttpRequestMessage(new HttpMethod("PATCH"), url);
            request.Content = new StringContent(body, Encoding.UTF8, "application/json");

            var response = _http.SendAsync(request).GetAwaiter().GetResult();
            response.EnsureSuccessStatusCode();
        }
    }
}