﻿using Flexi2.Core.MVVM;
using Flexi2.Models;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace Flexi2.ViewModels
{
    public sealed class TicketViewModel : ObservableObject
    {
        private readonly MainViewModel _main;
        public int TableId { get; }

        public ObservableCollection<OrderItem> LockedItems { get; } = new();
        public ObservableCollection<OrderItem> DraftItems { get; } = new();

        private string _title = "";
        public string Title
        {
            get => _title;
            set => Set(ref _title, value);
        }

        private decimal _total;
        public decimal Total
        {
            get => _total;
            set => Set(ref _total, value);
        }

        private string _error = "";
        public string Error
        {
            get => _error;
            set => Set(ref _error, value);
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get => _isBusy;
            set => Set(ref _isBusy, value);
        }

        public RelayCommand BackToFloorCommand { get; }
        public RelayCommand AddItemsCommand { get; }
        public RelayCommand IncDraftCommand { get; }
        public RelayCommand DecDraftCommand { get; }
        public RelayCommand RemoveLockedItemCommand { get; }
        public RelayCommand PlaceOrderCommand { get; }
        public RelayCommand CloseBillCommand { get; }

        public TicketViewModel(MainViewModel main, int tableId)
        {
            _main = main;
            TableId = tableId;

            Error = "";

            BackToFloorCommand = new RelayCommand(_ =>
                _main.Nav.NavigateTo(new FloorPlanViewModel(_main)));

            AddItemsCommand = new RelayCommand(_ =>
                _main.Nav.NavigateTo(new CategoryViewModel(_main, tableId, this)));

            IncDraftCommand = new RelayCommand(o =>
            {
                if (o is not OrderItem it) return;

                if (it.Qty < 0)
                {
                    it.Qty++;
                    if (it.Qty == 0)
                        DraftItems.Remove(it);
                }
                else
                {
                    it.Qty++;
                }

                Recalc();
                PlaceOrderCommand.RaiseCanExecuteChanged();
            });

            DecDraftCommand = new RelayCommand(o =>
            {
                if (o is not OrderItem it) return;

                if (it.Qty < 0)
                {
                    var lockedQty = LockedItems.Where(x => x.ProductId == it.ProductId && x.ProductName == it.ProductName).Sum(x => x.Qty);
                    if (Math.Abs(it.Qty) < lockedQty)
                        it.Qty--;
                    else
                        Error = "Не може да махнете повече бройки, отколкото са поръчани.";
                }
                else if (it.Qty > 1)
                {
                    it.Qty--;
                }
                else
                {
                    DraftItems.Remove(it);
                }

                Recalc();
                PlaceOrderCommand.RaiseCanExecuteChanged();
            });

            RemoveLockedItemCommand = new RelayCommand(async o =>
            {
                if (o is not OrderItem locked) return;
                await RemoveLockedItemWithAdminAsync(locked);
            });

            PlaceOrderCommand = new RelayCommand(async _ => await PlaceOrderAsync(), _ => DraftItems.Count > 0 && !IsBusy);

            CloseBillCommand = new RelayCommand(_ =>
            {
                if (IsBusy) return;
                _main.Nav.NavigateTo(new PaymentViewModel(_main, this));
            });

            _ = LoadAsync();
        }

        public void AddDraftProduct(Product p)
        {
            var existing = DraftItems.FirstOrDefault(x => x.ProductId == p.Id && x.ProductName == p.Name);

            if (existing != null)
            {
                existing.Qty++;
                if (existing.Qty == 0)
                    DraftItems.Remove(existing);
            }
            else
            {
                DraftItems.Add(new OrderItem
                {
                    ProductId = p.Id,
                    ProductName = p.Name,
                    UnitPrice = p.Price,
                    Qty = 1,
                    IsLocked = false
                });
            }

            Recalc();
            PlaceOrderCommand.RaiseCanExecuteChanged();
        }

        private void AddRemovalDraft(OrderItem locked)
        {
            Error = "";

            var existingRemoval = DraftItems.FirstOrDefault(x =>
                x.ProductId == locked.ProductId &&
                x.ProductName == locked.ProductName &&
                x.Qty < 0);

            var alreadyMarked = Math.Abs(existingRemoval?.Qty ?? 0);
            var lockedQty = LockedItems.Where(x => x.ProductId == locked.ProductId && x.ProductName == locked.ProductName).Sum(x => x.Qty);

            if (alreadyMarked >= lockedQty)
            {
                Error = "Не може да махнете повече бройки, отколкото са поръчани.";
                return;
            }

            if (existingRemoval != null)
            {
                existingRemoval.Qty--;
            }
            else
            {
                DraftItems.Add(new OrderItem
                {
                    ProductId = locked.ProductId,
                    ProductName = locked.ProductName,
                    UnitPrice = locked.UnitPrice,
                    Qty = -1,
                    IsLocked = false
                });
            }

            Recalc();
            PlaceOrderCommand.RaiseCanExecuteChanged();
        }


        private async Task RemoveLockedItemWithAdminAsync(OrderItem locked)
        {
            try
            {
                if (IsBusy) return;
                Error = "";

                var maxQty = LockedItems
                    .Where(x => x.ProductId == locked.ProductId && x.ProductName == locked.ProductName)
                    .Sum(x => x.Qty);

                if (maxQty <= 0)
                {
                    Error = "Няма налични бройки за изтриване.";
                    return;
                }

                var qtyToRemove = AskRemoveQuantity(locked.ProductName, maxQty);
                if (!qtyToRemove.HasValue || qtyToRemove.Value <= 0)
                    return;

                var pin = AskAdminPin();
                if (string.IsNullOrWhiteSpace(pin))
                {
                    Error = "Изтриването е отказано. Трябва админ код.";
                    return;
                }

                IsBusy = true;
                var admin = await _main.UsersRepo.TryLoginByPinAsync(pin, UserRole.Admin);
                if (admin == null)
                {
                    Error = "Грешен админ код. Продуктът не е изтрит.";
                    return;
                }

                var user = _main.Session.CurrentUser;
                if (user == null)
                {
                    Error = "Няма активен потребител.";
                    return;
                }

                await _main.PosService.PlaceOrderAsync(TableId, user.Id, new System.Collections.Generic.List<OrderItem>
                {
                    new OrderItem
                    {
                        ProductId = locked.ProductId,
                        ProductName = locked.ProductName,
                        UnitPrice = locked.UnitPrice,
                        Qty = -qtyToRemove.Value,
                        IsLocked = true
                    }
                });

                DraftItems.Clear();
                await LoadAsync();
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
                PlaceOrderCommand.RaiseCanExecuteChanged();
            }
        }

        private static int? AskRemoveQuantity(string productName, int maxQty)
        {
            var cyan = Color.FromRgb(0, 229, 255);
            var teal = Color.FromRgb(0, 255, 179);
            var neonRed = Color.FromRgb(255, 45, 80);
            var purple = Color.FromRgb(180, 0, 255);
            var modalBg = Color.FromRgb(7, 12, 24);

            ControlTemplate RoundButtonTemplate(double radius)
            {
                var template = new ControlTemplate(typeof(Button));
                var border = new FrameworkElementFactory(typeof(Border));
                border.SetValue(Border.CornerRadiusProperty, new CornerRadius(radius));
                border.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Button.BackgroundProperty));
                border.SetValue(Border.BorderBrushProperty, new TemplateBindingExtension(Button.BorderBrushProperty));
                border.SetValue(Border.BorderThicknessProperty, new TemplateBindingExtension(Button.BorderThicknessProperty));
                var content = new FrameworkElementFactory(typeof(ContentPresenter));
                content.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
                content.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
                border.AppendChild(content);
                template.VisualTree = border;
                return template;
            }

            var owner = Application.Current?.MainWindow;
            var oldEffect = owner?.Effect;
            if (owner != null)
            {
                owner.Effect = new System.Windows.Media.Effects.BlurEffect
                {
                    Radius = 13,
                    KernelType = System.Windows.Media.Effects.KernelType.Gaussian
                };
            }

            var win = new Window
            {
                Title = "Изтрий продукт",
                WindowStartupLocation = WindowStartupLocation.Manual,
                ResizeMode = ResizeMode.NoResize,
                Background = Brushes.Transparent,
                WindowStyle = WindowStyle.None,
                AllowsTransparency = true,
                ShowInTaskbar = false,
                Topmost = true
            };

            // Popup-ът за избор на брой трябва да покрива целия екран.
            // Не ползваме owner.Left/Top/ActualWidth, защото при maximized прозорец
            // може да остане празна ивица вляво.
            if (owner != null)
            {
                win.Owner = owner;
            }

            win.WindowStartupLocation = WindowStartupLocation.Manual;
            win.Left = SystemParameters.WorkArea.Left;
            win.Top = SystemParameters.WorkArea.Top;
            win.Width = SystemParameters.WorkArea.Width;
            win.Height = SystemParameters.WorkArea.Height;

            var qty = 1;

            var overlay = new Grid
            {
                Background = new SolidColorBrush(Color.FromArgb(220, 0, 4, 12))
            };

            var outer = new Border
            {
                Width = 560,
                MinHeight = 460,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Background = new SolidColorBrush(modalBg),
                CornerRadius = new CornerRadius(22),
                BorderBrush = new SolidColorBrush(neonRed),
                BorderThickness = new Thickness(2),
                Padding = new Thickness(28),
                Effect = new System.Windows.Media.Effects.DropShadowEffect
                {
                    Color = neonRed,
                    BlurRadius = 28,
                    ShadowDepth = 0,
                    Opacity = 0.45
                }
            };

            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            Button MakeButton(string text, Brush bg, Brush border, double width, double height, double fontSize)
            {
                return new Button
                {
                    Content = text,
                    Width = width,
                    Height = height,
                    FontSize = fontSize,
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.White,
                    Background = bg,
                    BorderBrush = border,
                    BorderThickness = new Thickness(2),
                    Cursor = System.Windows.Input.Cursors.Hand,
                    Margin = new Thickness(8),
                    Template = RoundButtonTemplate(14)
                };
            }

            var close = MakeButton("✕", new SolidColorBrush(Color.FromRgb(24, 6, 16)), new SolidColorBrush(neonRed), 46, 46, 24);
            close.Foreground = new SolidColorBrush(neonRed);
            close.HorizontalAlignment = HorizontalAlignment.Right;
            close.Click += (_, _) => { win.DialogResult = false; win.Close(); };
            Grid.SetRow(close, 0);
            root.Children.Add(close);

            var title = new TextBlock
            {
                Text = "ИЗТРИВАНЕ НА ПРОДУКТ",
                Foreground = new SolidColorBrush(neonRed),
                FontSize = 28,
                FontWeight = FontWeights.Bold,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 2, 0, 16)
            };
            Grid.SetRow(title, 1);
            root.Children.Add(title);

            var productBox = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(18, 28, 48)),
                BorderBrush = new SolidColorBrush(Color.FromRgb(55, 82, 135)),
                BorderThickness = new Thickness(1.5),
                CornerRadius = new CornerRadius(16),
                Padding = new Thickness(18),
                Margin = new Thickness(0, 0, 0, 20),
                Child = new StackPanel
                {
                    Children =
                    {
                        new TextBlock
                        {
                            Text = productName,
                            Foreground = Brushes.White,
                            FontSize = 22,
                            FontWeight = FontWeights.Bold,
                            TextWrapping = TextWrapping.Wrap,
                            TextAlignment = TextAlignment.Center
                        },
                        new TextBlock
                        {
                            Text = $"Налични бройки за изтриване: {maxQty}",
                            Foreground = new SolidColorBrush(Color.FromRgb(165, 185, 220)),
                            FontSize = 16,
                            FontWeight = FontWeights.SemiBold,
                            Margin = new Thickness(0, 8, 0, 0),
                            TextAlignment = TextAlignment.Center
                        }
                    }
                }
            };
            Grid.SetRow(productBox, 2);
            root.Children.Add(productBox);

            var qtyText = new TextBlock
            {
                Text = qty.ToString(),
                Foreground = new SolidColorBrush(teal),
                FontSize = 56,
                FontWeight = FontWeights.Bold,
                Width = 130,
                TextAlignment = TextAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };

            var minus = MakeButton("−", new SolidColorBrush(Color.FromRgb(32, 45, 75)), new SolidColorBrush(purple), 78, 72, 38);
            var plus = MakeButton("+", new SolidColorBrush(Color.FromRgb(32, 45, 75)), new SolidColorBrush(cyan), 78, 72, 34);
            minus.Click += (_, _) => { if (qty > 1) qty--; qtyText.Text = qty.ToString(); };
            plus.Click += (_, _) => { if (qty < maxQty) qty++; qtyText.Text = qty.ToString(); };

            var qtyPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 6, 0, 24)
            };
            qtyPanel.Children.Add(minus);
            qtyPanel.Children.Add(qtyText);
            qtyPanel.Children.Add(plus);
            Grid.SetRow(qtyPanel, 3);
            root.Children.Add(qtyPanel);

            var buttons = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            var cancel = MakeButton("ОТКАЗ", new SolidColorBrush(Color.FromRgb(15, 25, 44)), new SolidColorBrush(Color.FromRgb(95, 120, 165)), 175, 60, 16);
            var delete = MakeButton("ИЗТРИЙ ТОЗИ ПРОДУКТ", new LinearGradientBrush(neonRed, purple, 0), new SolidColorBrush(neonRed), 255, 60, 16);
            cancel.Click += (_, _) => { win.DialogResult = false; win.Close(); };
            delete.Click += (_, _) => { win.DialogResult = true; win.Close(); };
            buttons.Children.Add(cancel);
            buttons.Children.Add(delete);
            Grid.SetRow(buttons, 4);
            root.Children.Add(buttons);

            outer.Child = new ScrollViewer
            {
                Content = root,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                PanningMode = PanningMode.VerticalOnly,
                CanContentScroll = false
            };
            overlay.Children.Add(outer);
            win.Content = overlay;
            win.Closed += (_, _) => { if (owner != null) owner.Effect = oldEffect; };

            return win.ShowDialog() == true ? qty : null;
        }

        private async Task LoadAsync()
        {
            try
            {
                IsBusy = true;
                Error = "";

                var user = _main.Session.CurrentUser;
                if (user == null)
                {
                    Error = "Няма активен потребител.";
                    return;
                }

                var lockedItems = await _main.PosService.GetOpenOrderItemsByTable(TableId, user.Id);

                var total = lockedItems.Sum(i => i.UnitPrice * i.Qty)
                            + DraftItems.Sum(i => i.UnitPrice * i.Qty);

                Application.Current.Dispatcher.Invoke(() =>
                {
                    LockedItems.Clear();
                    foreach (var it in lockedItems)
                        LockedItems.Add(it);

                    Title = $"Сметка • Маса #{TableId}";
                    Total = total;
                    PlaceOrderCommand.RaiseCanExecuteChanged();
                });
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
                PlaceOrderCommand.RaiseCanExecuteChanged();
            }
        }

        private void Recalc()
        {
            var locked = LockedItems.Sum(i => i.UnitPrice * i.Qty);
            var draft = DraftItems.Sum(i => i.UnitPrice * i.Qty);
            Total = locked + draft;
        }

        private static string? AskAdminPin()
        {
            var cyan = Color.FromRgb(0, 229, 255);
            var teal = Color.FromRgb(0, 255, 179);
            var neonRed = Color.FromRgb(255, 45, 80);
            var purple = Color.FromRgb(180, 0, 255);
            var modalBg = Color.FromRgb(7, 12, 24);
            var inputBg = Color.FromRgb(12, 23, 43);

            ControlTemplate RoundButtonTemplate(double radius)
            {
                var template = new ControlTemplate(typeof(Button));
                var border = new FrameworkElementFactory(typeof(Border));
                border.SetValue(Border.CornerRadiusProperty, new CornerRadius(radius));
                border.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Button.BackgroundProperty));
                border.SetValue(Border.BorderBrushProperty, new TemplateBindingExtension(Button.BorderBrushProperty));
                border.SetValue(Border.BorderThicknessProperty, new TemplateBindingExtension(Button.BorderThicknessProperty));
                var content = new FrameworkElementFactory(typeof(ContentPresenter));
                content.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
                content.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
                content.SetValue(ContentPresenter.RecognizesAccessKeyProperty, true);
                border.AppendChild(content);
                template.VisualTree = border;
                return template;
            }

            var owner = Application.Current?.MainWindow;
            var oldEffect = owner?.Effect;
            if (owner != null)
            {
                owner.Effect = new System.Windows.Media.Effects.BlurEffect
                {
                    Radius = 13,
                    KernelType = System.Windows.Media.Effects.KernelType.Gaussian
                };
            }

            var win = new Window
            {
                Title = "Админ код",
                WindowStartupLocation = WindowStartupLocation.Manual,
                ResizeMode = ResizeMode.NoResize,
                Background = Brushes.Transparent,
                WindowStyle = WindowStyle.None,
                AllowsTransparency = true,
                ShowInTaskbar = false,
                Topmost = true
            };

            // Покрива целия екран при popup-а. Не ползваме owner.Left/Top,
            // защото при maximized прозорец WPF може да върне restore позиция
            // и остава празна ивица вляво/отдолу.
            if (owner != null)
            {
                win.Owner = owner;
            }

            win.WindowStartupLocation = WindowStartupLocation.Manual;
            win.Left = SystemParameters.WorkArea.Left;
            win.Top = SystemParameters.WorkArea.Top;
            win.Width = SystemParameters.WorkArea.Width;
            win.Height = SystemParameters.WorkArea.Height;

            var overlay = new Grid
            {
                Background = new SolidColorBrush(Color.FromArgb(220, 0, 4, 12))
            };

            var outer = new Border
            {
                Width = Math.Min(500, SystemParameters.WorkArea.Width - 40),
                MaxHeight = Math.Max(560, SystemParameters.WorkArea.Height - 40),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Background = new SolidColorBrush(modalBg),
                CornerRadius = new CornerRadius(20),
                BorderBrush = new SolidColorBrush(Color.FromRgb(64, 86, 130)),
                BorderThickness = new Thickness(1.5),
                Padding = new Thickness(24),
                Effect = new System.Windows.Media.Effects.DropShadowEffect
                {
                    Color = cyan,
                    BlurRadius = 22,
                    ShadowDepth = 0,
                    Opacity = 0.34
                }
            };

            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var close = new Button
            {
                Content = "✕",
                Width = 44,
                Height = 44,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top,
                FontFamily = new FontFamily("Segoe UI Symbol"),
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(neonRed),
                Background = new SolidColorBrush(Color.FromRgb(24, 6, 16)),
                BorderBrush = new SolidColorBrush(neonRed),
                BorderThickness = new Thickness(2),
                Cursor = System.Windows.Input.Cursors.Hand,
                Template = RoundButtonTemplate(9),
                Effect = new System.Windows.Media.Effects.DropShadowEffect
                {
                    Color = neonRed,
                    BlurRadius = 14,
                    ShadowDepth = 0,
                    Opacity = 0.45
                }
            };
            close.Click += (_, _) => { win.DialogResult = false; win.Close(); };
            Grid.SetRow(close, 0);
            root.Children.Add(close);

            var lockCircle = new Border
            {
                Width = 72,
                Height = 72,
                CornerRadius = new CornerRadius(36),
                BorderBrush = new SolidColorBrush(cyan),
                BorderThickness = new Thickness(2),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 8, 0, 14),
                Background = new SolidColorBrush(Color.FromRgb(9, 20, 39)),
                Effect = new System.Windows.Media.Effects.DropShadowEffect
                {
                    Color = purple,
                    BlurRadius = 18,
                    ShadowDepth = 0,
                    Opacity = 0.35
                },
                Child = new TextBlock
                {
                    Text = "🔒",
                    FontSize = 30,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                    Foreground = new SolidColorBrush(cyan)
                }
            };
            Grid.SetRow(lockCircle, 1);
            root.Children.Add(lockCircle);

            var title = new TextBlock
            {
                Text = "АДМИН КОД",
                Foreground = new SolidColorBrush(cyan),
                FontSize = 27,
                FontWeight = FontWeights.Bold,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 10)
            };
            Grid.SetRow(title, 2);
            root.Children.Add(title);

            var msg = new TextBlock
            {
                Text = "Въведи админ код, за да изтриеш\nизбрания продукт.",
                Foreground = Brushes.White,
                FontSize = 17,
                FontWeight = FontWeights.SemiBold,
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 12)
            };
            Grid.SetRow(msg, 3);
            root.Children.Add(msg);

            var body = new StackPanel();

            var inputWrap = new Border
            {
                Height = 50,
                Background = new SolidColorBrush(inputBg),
                BorderBrush = new SolidColorBrush(teal),
                BorderThickness = new Thickness(2),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(12, 0, 10, 0)
            };

            var inputGrid = new Grid();
            inputGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            inputGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var pass = new PasswordBox
            {
                Height = 44,
                FontSize = 22,
                Background = Brushes.Transparent,
                Foreground = Brushes.White,
                BorderThickness = new Thickness(0),
                Padding = new Thickness(0, 8, 8, 8),
                HorizontalContentAlignment = HorizontalAlignment.Left
            };
            Grid.SetColumn(pass, 0);
            inputGrid.Children.Add(pass);

            var placeholder = new TextBlock
            {
                Text = "Въведи админ код",
                Foreground = new SolidColorBrush(Color.FromRgb(165, 185, 220)),
                FontSize = 18,
                VerticalAlignment = VerticalAlignment.Center,
                IsHitTestVisible = false
            };
            Grid.SetColumn(placeholder, 0);
            inputGrid.Children.Add(placeholder);

            var shield = new TextBlock
            {
                Text = "▣",
                Foreground = new SolidColorBrush(Color.FromRgb(155, 205, 255)),
                FontSize = 22,
                Margin = new Thickness(14, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(shield, 1);
            inputGrid.Children.Add(shield);

            pass.PasswordChanged += (_, _) => placeholder.Visibility = string.IsNullOrEmpty(pass.Password) ? Visibility.Visible : Visibility.Collapsed;
            inputWrap.Child = inputGrid;
            body.Children.Add(inputWrap);

            Button MakeKey(string text)
            {
                return new Button
                {
                    Content = text,
                    Height = 46,
                    FontSize = 20,
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.White,
                    Background = new SolidColorBrush(Color.FromRgb(23, 35, 67)),
                    BorderBrush = new SolidColorBrush(cyan),
                    BorderThickness = new Thickness(1.5),
                    Margin = new Thickness(5),
                    Cursor = System.Windows.Input.Cursors.Hand,
                    Template = RoundButtonTemplate(12)
                };
            }

            var keypad = new UniformGrid
            {
                Columns = 3,
                Rows = 4,
                Margin = new Thickness(0, 12, 0, 12)
            };

            string[] keys = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "⌫" };
            foreach (var k in keys)
            {
                var key = MakeKey(k);
                if (k == "C") key.BorderBrush = new SolidColorBrush(purple);
                if (k == "⌫") key.BorderBrush = new SolidColorBrush(neonRed);
                key.Click += (_, _) =>
                {
                    if (k == "C")
                    {
                        pass.Password = "";
                    }
                    else if (k == "⌫")
                    {
                        if (pass.Password.Length > 0)
                            pass.Password = pass.Password.Substring(0, pass.Password.Length - 1);
                    }
                    else
                    {
                        pass.Password += k;
                    }
                    pass.Focus();
                };
                keypad.Children.Add(key);
            }
            body.Children.Add(keypad);

            var separator = new DockPanel { Margin = new Thickness(0, 0, 0, 12), HorizontalAlignment = HorizontalAlignment.Center };
            separator.Children.Add(new Border { Height = 1, Width = 145, Background = new SolidColorBrush(Color.FromRgb(58, 72, 100)), VerticalAlignment = VerticalAlignment.Center });
            separator.Children.Add(new TextBlock { Text = "🔒", Foreground = new SolidColorBrush(Color.FromRgb(155, 205, 255)), FontSize = 18, Margin = new Thickness(12, 0, 12, 0), VerticalAlignment = VerticalAlignment.Center });
            separator.Children.Add(new Border { Height = 1, Width = 145, Background = new SolidColorBrush(Color.FromRgb(58, 72, 100)), VerticalAlignment = VerticalAlignment.Center });
            body.Children.Add(separator);

            Button MakeDialogButton(string text, Brush background, Brush border, double width)
            {
                return new Button
                {
                    Content = text,
                    Width = width,
                    Height = 50,
                    FontSize = 16,
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.White,
                    Background = background,
                    BorderBrush = border,
                    BorderThickness = new Thickness(2),
                    Cursor = System.Windows.Input.Cursors.Hand,
                    Margin = new Thickness(8, 0, 8, 0),
                    Template = RoundButtonTemplate(14)
                };
            }

            var buttons = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var cancel = MakeDialogButton("ОТКАЗ", new SolidColorBrush(Color.FromRgb(15, 25, 44)), new SolidColorBrush(Color.FromRgb(95, 120, 165)), 170);
            var ok = MakeDialogButton("ПОТВЪРДИ", new LinearGradientBrush(cyan, purple, 0), new SolidColorBrush(cyan), 190);
            ok.Click += (_, _) => { win.DialogResult = true; win.Close(); };
            cancel.Click += (_, _) => { win.DialogResult = false; win.Close(); };
            void ConfirmAdminPin()
            {
                win.DialogResult = true;
                win.Close();
            }

            pass.KeyDown += (_, e) =>
            {
                if (e.Key == System.Windows.Input.Key.Enter || e.Key == System.Windows.Input.Key.Return)
                {
                    e.Handled = true;
                    ConfirmAdminPin();
                }
            };

            win.PreviewKeyDown += (_, e) =>
            {
                string? digit = null;

                if (e.Key >= System.Windows.Input.Key.D0 && e.Key <= System.Windows.Input.Key.D9)
                    digit = ((int)(e.Key - System.Windows.Input.Key.D0)).ToString();
                else if (e.Key >= System.Windows.Input.Key.NumPad0 && e.Key <= System.Windows.Input.Key.NumPad9)
                    digit = ((int)(e.Key - System.Windows.Input.Key.NumPad0)).ToString();

                if (digit != null)
                {
                    if (pass.Password.Length < 8)
                        pass.Password += digit;
                    pass.Focus();
                    e.Handled = true;
                    return;
                }

                if (e.Key == System.Windows.Input.Key.Back || e.Key == System.Windows.Input.Key.Delete)
                {
                    if (pass.Password.Length > 0)
                        pass.Password = pass.Password.Substring(0, pass.Password.Length - 1);
                    pass.Focus();
                    e.Handled = true;
                    return;
                }

                if (e.Key == System.Windows.Input.Key.Escape)
                {
                    pass.Password = string.Empty;
                    pass.Focus();
                    e.Handled = true;
                    return;
                }

                if (e.Key == System.Windows.Input.Key.Enter || e.Key == System.Windows.Input.Key.Return)
                {
                    e.Handled = true;
                    ConfirmAdminPin();
                }
            };

            buttons.Children.Add(cancel);
            buttons.Children.Add(ok);
            body.Children.Add(buttons);

            Grid.SetRow(body, 4);
            root.Children.Add(body);

            outer.Child = new ScrollViewer
            {
                Content = root,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                PanningMode = PanningMode.VerticalOnly,
                CanContentScroll = false
            };
            overlay.Children.Add(outer);
            win.Content = overlay;
            win.Loaded += (_, _) => pass.Focus();
            win.Closed += (_, _) =>
            {
                if (owner != null)
                    owner.Effect = oldEffect;
            };

            return win.ShowDialog() == true ? pass.Password : null;
        }

        private async Task PlaceOrderAsync()
        {
            try
            {
                IsBusy = true;
                Error = "";

                var user = _main.Session.CurrentUser;
                if (user == null)
                {
                    Error = "Няма активен потребител.";
                    return;
                }

                if (DraftItems.Any(x => x.Qty < 0))
                {
                    var pin = AskAdminPin();
                    if (string.IsNullOrWhiteSpace(pin))
                    {
                        Error = "Промяната не е запазена. Трябва админ код.";
                        return;
                    }

                    var admin = await _main.UsersRepo.TryLoginByPinAsync(pin, UserRole.Admin);
                    if (admin == null)
                    {
                        Error = "Грешен админ код. Промяната не е запазена.";
                        return;
                    }
                }

                var draftCopy = DraftItems.Where(d => d.Qty != 0).Select(d => new OrderItem
                {
                    ProductId = d.ProductId,
                    ProductName = d.ProductName,
                    UnitPrice = d.UnitPrice,
                    Qty = d.Qty,
                    IsLocked = true
                }).ToList();

                await _main.PosService.PlaceOrderAsync(TableId, user.Id, draftCopy);               

                Application.Current.Dispatcher.Invoke(() =>
                {
                    DraftItems.Clear();
                    PlaceOrderCommand.RaiseCanExecuteChanged();
                });

                await LoadAsync();
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
                PlaceOrderCommand.RaiseCanExecuteChanged();
            }
        }
    }
}