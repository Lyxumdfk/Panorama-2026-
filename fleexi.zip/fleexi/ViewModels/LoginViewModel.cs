﻿using System.Windows;
using System.Linq;
using Flexi2.Core.MVVM;
using Flexi2.Models;

namespace Flexi2.ViewModels
{
    public sealed class LoginViewModel : ObservableObject
    {
        private readonly MainViewModel _main;

        private string _pin = string.Empty;
        public string Pin
        {
            get => _pin;
            set
            {
                _pin = new string((value ?? string.Empty).Where(char.IsDigit).Take(4).ToArray());
                OnPropertyChanged();
                OnPropertyChanged(nameof(MaskedPin));
            }
        }

        public string MaskedPin => string.IsNullOrEmpty(Pin)
            ? string.Empty
            : string.Join(" ", Enumerable.Repeat("*", Pin.Length));

        private string _error = string.Empty;
        public string Error
        {
            get => _error;
            set { _error = value; OnPropertyChanged(); }
        }

        private bool _isAdminSelected;
        public bool IsAdminSelected
        {
            get => _isAdminSelected;
            set { _isAdminSelected = value; OnPropertyChanged(); }
        }

        // UI commands
        public RelayCommand SelectPosCommand { get; }
        public RelayCommand SelectAdminCommand { get; }
        public RelayCommand DigitCommand { get; }
        public RelayCommand ClearCommand { get; }
        public RelayCommand DeleteCommand { get; }

        public RelayCommand EnterCommand { get; }
        public RelayCommand ExitCommand { get; }

        public LoginViewModel(MainViewModel main)
        {
            _main = main;

            SelectPosCommand = new RelayCommand(_ => SelectPos());
            SelectAdminCommand = new RelayCommand(_ => SelectAdmin());
            DigitCommand = new RelayCommand(AddDigit);
            ClearCommand = new RelayCommand(_ => Pin = string.Empty);
            DeleteCommand = new RelayCommand(_ =>
            {
                if (!string.IsNullOrEmpty(Pin))
                    Pin = Pin[..^1];
            });

            EnterCommand = new RelayCommand(async _ => await LoginAsync());
            ExitCommand = new RelayCommand(_ => Application.Current.Shutdown());

            // default: POS
            IsAdminSelected = false;
        }

        private void SelectPos()
        {
            IsAdminSelected = false;
            Error = string.Empty;
        }

        private void SelectAdmin()
        {
            IsAdminSelected = true;
            Error = string.Empty;
        }

        private void AddDigit(object? digit)
        {
            var d = digit?.ToString() ?? string.Empty;
            if (d.Length == 1 && char.IsDigit(d[0]) && Pin.Length < 4)
            {
                Pin += d;
                Error = string.Empty;
            }
        }

        private async Task LoginAsync()
        {
            Error = string.Empty;
            var pin = (Pin ?? string.Empty).Trim();

            if (pin.Length == 0)
            {
                Error = "Въведи PIN";
                return;
            }

            var role = IsAdminSelected ? UserRole.Admin : UserRole.Pos;

            var user = await _main.UsersRepo.TryLoginByPinAsync(pin, role);
            if (user == null)
            {
                Error = IsAdminSelected ? "Грешен admin код" : "Този код не е POS";
                return;
            }

            _main.Session.SetUser(user);

            var loginLogId = await _main.PosService.LogLoginAsync(user);
            _main.Session.CurrentLoginLogId = loginLogId;

            if ((UserRole)user.RoleValue == UserRole.Admin)
                _main.Nav.NavigateTo(new AdminViewModel(_main));
            else
                _main.Nav.NavigateTo(new FloorPlanViewModel(_main));
        }
    }
}
