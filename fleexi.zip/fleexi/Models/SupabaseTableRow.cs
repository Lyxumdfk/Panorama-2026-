﻿using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;

namespace Flexi2.Models
{
    [Table("tables")]
    public class SupabaseTableRow : BaseModel
    {
        [PrimaryKey("id", false)]
        public int Id { get; set; }

        [Column("zone_id")]
        public int ZoneId { get; set; }

        [Column("name")]
        public string Name { get; set; } = string.Empty;

        [Column("pos_x")]
        public double PosX { get; set; }

        [Column("pos_y")]
        public double PosY { get; set; }

        [Column("width")]
        public double Width { get; set; }

        [Column("height")]
        public double Height { get; set; }

        [Column("shape_type")]
        public int ShapeType { get; set; }

        [Column("status")]
        public int Status { get; set; }

        [Column("owner_user_id")]
        public int? OwnerUserId { get; set; }

        [Column("opened_at_utc")]
        public string? OpenedAtUtc { get; set; }

        [Column("current_total")]
        public decimal? CurrentTotal { get; set; }
    }
}