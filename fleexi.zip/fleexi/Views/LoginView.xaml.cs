using Flexi2.ViewModels;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Flexi2.Views
{
    public partial class LoginView : UserControl
    {
        public LoginView()
        {
            InitializeComponent();

            Focusable = true;
            Loaded += (_, _) =>
            {
                Keyboard.Focus(this);
                Focus();
            };

            PreviewMouseDown += (_, _) =>
            {
                if (!IsKeyboardFocusWithin)
                    Focus();
            };

            PreviewKeyDown += LoginView_PreviewKeyDown;
        }

        private void LoginView_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (DataContext is not LoginViewModel vm)
                return;

            string? digit = null;

            if (e.Key >= Key.D0 && e.Key <= Key.D9)
                digit = ((int)(e.Key - Key.D0)).ToString();
            else if (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9)
                digit = ((int)(e.Key - Key.NumPad0)).ToString();

            if (digit != null)
            {
                vm.DigitCommand.Execute(digit);
                e.Handled = true;
                return;
            }

            if (e.Key == Key.Back || e.Key == Key.Delete)
            {
                vm.DeleteCommand.Execute(null);
                e.Handled = true;
                return;
            }

            if (e.Key == Key.Escape)
            {
                vm.ClearCommand.Execute(null);
                e.Handled = true;
                return;
            }

            if (e.Key == Key.Enter || e.Key == Key.Return)
            {
                vm.EnterCommand.Execute(null);
                e.Handled = true;
            }
        }
    }
}
