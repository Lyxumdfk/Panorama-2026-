﻿using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;

namespace Flexi2.Models
{
    [Table("zones")]
    public class SupabaseZoneRow : BaseModel
    {
        [PrimaryKey("id", false)]
        public int Id { get; set; }

        [Column("name")]
        public string Name { get; set; } = string.Empty;
    }
}