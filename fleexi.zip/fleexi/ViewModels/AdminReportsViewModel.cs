using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Flexi2.Core.MVVM;
using Flexi2.Models;
using System.Windows;
using System.Windows.Threading;

namespace Flexi2.ViewModels
{
    public sealed class AdminReportsViewModel : ObservableObject
    {
        private readonly MainViewModel _main;

        public ObservableCollection<TurnoverEntry> Entries { get; } = new();
        public ObservableCollection<UserRow> Waiters { get; } = new();
        public ObservableCollection<TurnoverEntry> WaiterEntries { get; } = new();

        private decimal _total;
        public decimal Total { get => _total; set => Set(ref _total, value); }

        private string _rangeLabel = "";
        public string RangeLabel { get => _rangeLabel; set => Set(ref _rangeLabel, value); }

        private string _error = "";
        public string Error { get => _error; set => Set(ref _error, value); }

        private UserRow? _selectedWaiter;
        public UserRow? SelectedWaiter { get => _selectedWaiter; set { if (Set(ref _selectedWaiter, value)) _ = LoadWaiterReportAsync(); } }

        private bool _isWaiterReportOpen;
        public bool IsWaiterReportOpen { get => _isWaiterReportOpen; set => Set(ref _isWaiterReportOpen, value); }

        private decimal _waiterTotal;
        public decimal WaiterTotal { get => _waiterTotal; set => Set(ref _waiterTotal, value); }

        private string _waiterReportTitle = "Отчет за сервитьор";
        public string WaiterReportTitle { get => _waiterReportTitle; set => Set(ref _waiterReportTitle, value); }

        private DateTime _waiterFromDate = DateTime.Now.Date;
        public DateTime WaiterFromDate { get => _waiterFromDate; set { if (Set(ref _waiterFromDate, value.Date)) _ = LoadWaiterReportAsync(); } }

        private DateTime _waiterToDate = DateTime.Now.Date;
        public DateTime WaiterToDate { get => _waiterToDate; set { if (Set(ref _waiterToDate, value.Date)) _ = LoadWaiterReportAsync(); } }


        private bool _isBusy;
        public bool IsBusy { get => _isBusy; set => Set(ref _isBusy, value); }

        private (DateTime fromUtc, DateTime toUtc, string label) _currentRange;
        private readonly DispatcherTimer _refreshTimer;

        public RelayCommand TodayCommand { get; }
        public RelayCommand WeekCommand { get; }
        public RelayCommand MonthCommand { get; }
        public RelayCommand YearCommand { get; }
        public RelayCommand BackCommand { get; }
        public RelayCommand BackToActivitiesCommand { get; }
        public RelayCommand OpenWaiterReportCommand { get; }
        public RelayCommand CloseWaiterReportCommand { get; }
        public RelayCommand RefreshWaiterReportCommand { get; }
        public RelayCommand WaiterTodayCommand { get; }
        public RelayCommand WaiterWeekCommand { get; }
        public RelayCommand WaiterMonthCommand { get; }
        public RelayCommand WaiterYearCommand { get; }

        public AdminReportsViewModel(MainViewModel main)
        {
            _main = main;

            TodayCommand = new RelayCommand(async _ => await LoadRangeAsync(RangeToday()));
            WeekCommand = new RelayCommand(async _ => await LoadRangeAsync(RangeWeek()));
            MonthCommand = new RelayCommand(async _ => await LoadRangeAsync(RangeMonth()));
            YearCommand = new RelayCommand(async _ => await LoadRangeAsync(RangeYear()));
            BackCommand = new RelayCommand(_ => _main.Nav.NavigateTo(new AdminViewModel(_main)));
            BackToActivitiesCommand = new RelayCommand(_ =>
            {
                _main.Session.Logout();
                _main.Nav.NavigateTo(new LoginViewModel(_main));
            });
            OpenWaiterReportCommand = new RelayCommand(async _ => await OpenWaiterReportAsync());
            CloseWaiterReportCommand = new RelayCommand(_ => IsWaiterReportOpen = false);
            RefreshWaiterReportCommand = new RelayCommand(async _ => await LoadWaiterReportAsync());
            WaiterTodayCommand = new RelayCommand(async _ => { var d = DateTime.Now.Date; WaiterFromDate = d; WaiterToDate = d; await LoadWaiterReportAsync(); });
            WaiterWeekCommand = new RelayCommand(async _ => { var now = DateTime.Now; var diff = ((int)now.DayOfWeek + 6) % 7; WaiterFromDate = now.Date.AddDays(-diff); WaiterToDate = WaiterFromDate.AddDays(6); await LoadWaiterReportAsync(); });
            WaiterMonthCommand = new RelayCommand(async _ => { var now = DateTime.Now; WaiterFromDate = new DateTime(now.Year, now.Month, 1); WaiterToDate = WaiterFromDate.AddMonths(1).AddDays(-1); await LoadWaiterReportAsync(); });
            WaiterYearCommand = new RelayCommand(async _ => { var now = DateTime.Now; WaiterFromDate = new DateTime(now.Year, 1, 1); WaiterToDate = new DateTime(now.Year, 12, 31); await LoadWaiterReportAsync(); });

            _currentRange = RangeToday();
            _ = LoadRangeAsync(_currentRange);

            // Realtime refresh: Supabase понякога праща събитието малко преди update-ът да се вижда напълно.
            // Затова презареждаме веднага и още веднъж след кратко забавяне.
            _main.Realtime.TableChanged += table =>
            {
                if (table == "orders" || table == "order_items" || table == "users" || table == "products")
                {
                    Application.Current.Dispatcher.Invoke(async () =>
                    {
                        await LoadRangeAsync(_currentRange);
                        if (IsWaiterReportOpen) await LoadWaiterReportAsync();
                        await Task.Delay(700);
                        await LoadRangeAsync(_currentRange);
                        if (IsWaiterReportOpen) await LoadWaiterReportAsync();
                    });
                }
            };

            // Резервно автоматично обновяване, ако Realtime каналът изпусне събитие.
            _refreshTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(3)
            };
            _refreshTimer.Tick += async (_, __) => await LoadRangeAsync(_currentRange);
            _refreshTimer.Start();
        }

        private async Task OpenWaiterReportAsync()
        {
            await LoadWaitersAsync();
            var fromLocal = _currentRange.fromUtc.ToLocalTime().Date;
            var toLocal = _currentRange.toUtc.ToLocalTime().Date.AddDays(-1);
            if (toLocal < fromLocal) toLocal = fromLocal;
            WaiterFromDate = fromLocal;
            WaiterToDate = toLocal;
            IsWaiterReportOpen = true;
            await LoadWaiterReportAsync();
        }

        private async Task LoadWaitersAsync()
        {
            if (Waiters.Count > 0) return;
            try
            {
                var usersResult = await App.SupabaseClient.From<UserRow>().Get();
                var users = usersResult.Models
                    .Where(u => u.IsActive && u.RoleValue == 0)
                    .OrderBy(u => u.Name)
                    .ToList();

                Application.Current.Dispatcher.Invoke(() =>
                {
                    Waiters.Clear();
                    foreach (var u in users) Waiters.Add(u);
                    if (SelectedWaiter == null && Waiters.Count > 0) SelectedWaiter = Waiters[0];
                });
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
        }

        private async Task LoadWaiterReportAsync()
        {
            if (SelectedWaiter == null) return;
            try
            {
                var fromLocal = WaiterFromDate.Date;
                var toLocalExclusive = WaiterToDate.Date.AddDays(1);
                if (toLocalExclusive <= fromLocal) toLocalExclusive = fromLocal.AddDays(1);

                var all = await _main.ReportsRepo.GetTurnoverEntriesAsync(fromLocal.ToUniversalTime(), toLocalExclusive.ToUniversalTime(), 500);
                var filtered = all.Where(x => x.UserId == SelectedWaiter.Id).ToList();
                Application.Current.Dispatcher.Invoke(() =>
                {
                    WaiterEntries.Clear();
                    foreach (var e in filtered) WaiterEntries.Add(e);
                    WaiterTotal = filtered.Sum(x => x.TotalAfterDiscount);
                    WaiterReportTitle = $"Отчет за сервитьор: {SelectedWaiter.Name}";
                });
            }
            catch (Exception ex)
            {
                Error = ex.Message;
                WaiterEntries.Clear();
                WaiterTotal = 0m;
            }
        }

        private static (DateTime fromUtc, DateTime toUtc, string label) RangeToday()
        {
            var startLocal = DateTime.Now.Date;
            var endLocal = startLocal.AddDays(1);
            return (startLocal.ToUniversalTime(), endLocal.ToUniversalTime(), $"Днес ({startLocal:dd.MM.yyyy})");
        }

        private static (DateTime fromUtc, DateTime toUtc, string label) RangeWeek()
        {
            var now = DateTime.Now;
            var diff = ((int)now.DayOfWeek + 6) % 7;
            var startLocal = now.Date.AddDays(-diff);
            var endLocal = startLocal.AddDays(7);
            return (startLocal.ToUniversalTime(), endLocal.ToUniversalTime(), $"Седмица ({startLocal:dd.MM} - {endLocal.AddDays(-1):dd.MM})");
        }

        private static (DateTime fromUtc, DateTime toUtc, string label) RangeMonth()
        {
            var now = DateTime.Now;
            var startLocal = new DateTime(now.Year, now.Month, 1);
            var endLocal = startLocal.AddMonths(1);
            return (startLocal.ToUniversalTime(), endLocal.ToUniversalTime(), $"Месец ({startLocal:MMMM yyyy})");
        }

        private static (DateTime fromUtc, DateTime toUtc, string label) RangeYear()
        {
            var now = DateTime.Now;
            var startLocal = new DateTime(now.Year, 1, 1);
            var endLocal = startLocal.AddYears(1);
            return (startLocal.ToUniversalTime(), endLocal.ToUniversalTime(), $"Година ({startLocal:yyyy})");
        }

        private async Task LoadRangeAsync((DateTime fromUtc, DateTime toUtc, string label) range)
        {
            try
            {
                IsBusy = true;
                Error = "";
                _currentRange = range;
                RangeLabel = range.label;

                var entries = await _main.ReportsRepo.GetTurnoverEntriesAsync(range.fromUtc, range.toUtc);

                Application.Current.Dispatcher.Invoke(() =>
                {
                    Entries.Clear();
                    foreach (var e in entries)
                        Entries.Add(e);

                    Total = 0;
                    foreach (var e in Entries)
                        Total += e.TotalAfterDiscount;
                });
            }
            catch (Exception ex)
            {
                Error = ex.Message;
                Total = 0;
                Entries.Clear();
            }
            finally
            {
                IsBusy = false;
            }
        }
    }
}
